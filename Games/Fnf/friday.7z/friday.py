import pygame
import random
import time
import json
import os

# Initialize pygame
pygame.init()

# Load configurations from JSON
config_path = "config.json"
if not os.path.exists(config_path):
    config = {
        "note_spawn_rate": 30,
        "note_speed": 5,
        "fps_limit": 30,
        "health_max": 100,
        "health_gain": 1,
        "health_loss": 5
    }
    with open(config_path, "w") as config_file:
        json.dump(config, config_file, indent=4)
else:
    with open(config_path, "r") as config_file:
        config = json.load(config_file)

# Screen settings
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Friday Night Funkin' em Python")
pygame.mouse.set_visible(False)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Arrow settings
arrow_size = 50
arrow_speed = config["note_speed"]
keys = [pygame.K_d, pygame.K_f, pygame.K_j, pygame.K_k]
arrow_images = {
    pygame.K_d: pygame.image.load("assets/left_arrow.png"),
    pygame.K_f: pygame.image.load("assets/down_arrow.png"),
    pygame.K_j: pygame.image.load("assets/up_arrow.png"),
    pygame.K_k: pygame.image.load("assets/right_arrow.png")
}

pressed_arrow_images = {
    pygame.K_d: pygame.image.load("assets/left_arrow_pressed.png"),
    pygame.K_f: pygame.image.load("assets/down_arrow_pressed.png"),
    pygame.K_j: pygame.image.load("assets/up_arrow_pressed.png"),
    pygame.K_k: pygame.image.load("assets/right_arrow_pressed.png")
}

boy_images = {
    "idle": pygame.image.load("assets/boy_idle.png"),
    pygame.K_d: pygame.image.load("assets/boy_d.png"),
    pygame.K_f: pygame.image.load("assets/boy_f.png"),
    pygame.K_j: pygame.image.load("assets/boy_j.png"),
    pygame.K_k: pygame.image.load("assets/boy_k.png")
}

boy_x, boy_y = 0, 10  # Character position
current_boy_image = boy_images["idle"]
boy_animation_end = 0  # Time to return to idle

# Fixed arrow positions (centered at the bottom)
arrow_positions = {
    pygame.K_d: (140, HEIGHT - 140),
    pygame.K_f: (290, HEIGHT - 140),
    pygame.K_j: (390, HEIGHT - 150),
    pygame.K_k: (540, HEIGHT - 140)
}

pressed_keys = {key: False for key in keys}

class Arrow:
    def __init__(self, key):
        self.key = key
        self.x, _ = arrow_positions[key]
        self.y = 0  # Starts at the top of the screen

    def move(self):
        self.y += arrow_speed

    def draw(self):
        screen.blit(arrow_images[self.key], (self.x, self.y))

    def hitbox(self):
        return pygame.Rect(self.x, self.y, arrow_size, arrow_size)

# List of falling arrows
arrows = []
score = 0
errors = 0
botplay = False  # Botplay state
health = config["health_max"]

running = True
clock = pygame.time.Clock()

while running:
    screen.fill(BLACK)

    # Draw fixed arrows
    for key in keys:
        if pressed_keys[key]:
            screen.blit(pressed_arrow_images[key], (arrow_positions[key][0], arrow_positions[key][1]))
        else:
            screen.blit(arrow_images[key], (arrow_positions[key][0], arrow_positions[key][1]))

    # Reset character animation after 0.5 seconds
    if time.time() > boy_animation_end:
        current_boy_image = boy_images["idle"]

    # Draw character
    screen.blit(current_boy_image, (boy_x, boy_y))

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_b:
                botplay = not botplay  # Toggle botplay
            if event.key in pressed_keys:
                pressed_keys[event.key] = True
                current_boy_image = boy_images.get(event.key, boy_images["idle"])
                boy_animation_end = time.time() + 0.5  # Keep a animação pressionada por 0.5 segundos

    if event.type == pygame.KEYUP:
        if event.key in pressed_keys:
            pressed_keys[event.key] = False

    # Update arrows
    if random.randint(1, config["note_spawn_rate"]) == 1:
        arrows.append(Arrow(random.choice(keys)))

    for arrow in arrows:
        arrow.move()
        if arrow.y > HEIGHT:
            arrows.remove(arrow)
            errors += 1

    # Draw arrows
    for arrow in arrows:
        arrow.draw()

    # Display FPS
    fps = clock.get_fps()
    font = pygame.font.Font(None, 36)
    fps_text = font.render(f"FPS: {int(fps)}", True, WHITE)
    screen.blit(fps_text, (10, 10))

    pygame.display.flip()
    clock.tick(config["fps_limit"])

pygame.quit()