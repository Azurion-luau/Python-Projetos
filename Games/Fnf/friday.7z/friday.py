import pygame
import random
import time
import json
import os

# Initialize pygame
pygame.init()

# Load configurations from JSON
config_path = "config.json"
if not os.path.exists(config_path):
    config = {
        "note_spawn_rate": 30,
        "note_speed": 5,
        "fps_limit": 30,
        "health_max": 100,
        "health_gain": 1,
        "health_loss": 5,
        "botplay_level": 1  # Nível do botplay (1 a 5)
    }
    with open(config_path, "w") as config_file:
        json.dump(config, config_file, indent=4)
else:
    with open(config_path, "r") as config_file:
        config = json.load(config_file)

# Screen settings
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Friday Night Funkin' em Python")
pygame.mouse.set_visible(False)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Arrow settings
arrow_size = 50
arrow_speed = config["note_speed"]
keys = [pygame.K_d, pygame.K_f, pygame.K_j, pygame.K_k]
arrow_images = {
    pygame.K_d: pygame.image.load("assets/left_arrow.png"),
    pygame.K_f: pygame.image.load("assets/down_arrow.png"),
    pygame.K_j: pygame.image.load("assets/up_arrow.png"),
    pygame.K_k: pygame.image.load("assets/right_arrow.png")
}

pressed_arrow_images = {
    pygame.K_d: pygame.image.load("assets/left_arrow_pressed.png"),
    pygame.K_f: pygame.image.load("assets/down_arrow_pressed.png"),
    pygame.K_j: pygame.image.load("assets/up_arrow_pressed.png"),
    pygame.K_k: pygame.image.load("assets/right_arrow_pressed.png")
}

boy_images = {
    "idle": pygame.image.load("assets/boy_idle.png"),
    pygame.K_d: pygame.image.load("assets/boy_d.png"),
    pygame.K_f: pygame.image.load("assets/boy_f.png"),
    pygame.K_j: pygame.image.load("assets/boy_j.png"),
    pygame.K_k: pygame.image.load("assets/boy_k.png")
}

boy_x, boy_y = 0, 10  # Character position
current_boy_image = boy_images["idle"]
boy_animation_end = 0  # Time to return to idle

# Fixed arrow positions (centered at the bottom)
arrow_positions = {
    pygame.K_d: (140, HEIGHT - 140),
    pygame.K_f: (290, HEIGHT - 140),
    pygame.K_j: (390, HEIGHT - 150),
    pygame.K_k: (540, HEIGHT - 140)
}

pressed_keys = {key: False for key in keys}

class Arrow:
    def __init__(self, key):
        self.key = key
        self.x, _ = arrow_positions[key]
        self.y = 0  # Starts at the top of the screen

    def move(self):
        self.y += arrow_speed

    def draw(self):
        screen.blit(arrow_images[self.key], (self.x, self.y))

    def hitbox(self):
        return pygame.Rect(self.x, self.y, arrow_size, arrow_size)

# List of falling arrows
arrows = []
score = 0
errors = 0
botplay = False  # Botplay state
health = config["health_max"]

running = True
clock = pygame.time.Clock()

while running:
    screen.fill(BLACK)

    # Draw fixed arrows
    for key in keys:
        if pressed_keys[key]:
            screen.blit(pressed_arrow_images[key], (arrow_positions[key][0], arrow_positions[key][1]))
        else:
            screen.blit(arrow_images[key], (arrow_positions[key][0], arrow_positions[key][1]))

    # Reset character animation after 0.5 seconds
    if time.time() > boy_animation_end:
        current_boy_image = boy_images["idle"]

    # Draw character
    screen.blit(current_boy_image, (boy_x, boy_y))

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_b:
                botplay = not botplay  # Toggle botplay
            if event.key in pressed_keys:
                pressed_keys[event.key] = True
                current_boy_image = boy_images.get(event.key, boy_images["idle"])
                boy_animation_end = time.time() + 0.5  # Keep animation for 0.5 seconds

            for arrow in arrows[:]:
                if event.key == arrow.key:
                    hitbox = arrow.hitbox()
                    target_y = arrow_positions[event.key][1]
                    distance = abs(hitbox.y - target_y)

                    if distance < 10:
                        score += 13
                        health = min(config["health_max"], health + config["health_gain"])
                    elif distance < 25:
                        score += 8
                        health = min(config["health_max"], health + config["health_gain"])
                    elif distance < 50:
                        score += 3
                    elif distance < 100:
                        score -= 3
                    else:
                        score -= 3
                        errors += 1
                        health = max(0, health - config["health_loss"])

                    arrows.remove(arrow)
                    break

        if event.type == pygame.KEYUP:
            if event.key in pressed_keys:
                pressed_keys[event.key] = False

    # Create new random arrows
    if random.randint(1, config["note_spawn_rate"]) == 1:
        arrows.append(Arrow(random.choice(keys)))

    # Move and draw falling arrows
    for arrow in arrows:
        arrow.move()
        arrow.draw()
        if arrow.y > HEIGHT:
            arrows.remove(arrow)
            errors += 1
            health = max(0, health - config["health_loss"])

    # Botplay logic
    if botplay:
        for arrow in arrows:
            if arrow.y >= HEIGHT - 150:  # Check if the arrow is close to the target position
                # Determine the chance of error based on botplay level
                error_chance = random.randint(1, 100)  # Random number between 1 and 100
                if config["botplay_level"] == 1:
                    if error_chance <= 80:  # 80% chance to errar
                        continue  # Erra e não pressiona a tecla
                elif config["botplay_level"] == 2:
                    if error_chance <= 60:  # 60% chance to errar
                        continue
                elif config["botplay_level"] == 3:
                    if error_chance <= 40:  # 40% chance to errar
                        continue
                elif config["botplay_level"] == 4:
                    if error_chance <= 20:  # 20% chance to errar
                        continue
                elif config["botplay_level"] == 5:
                    # Nível 5 nunca erra
                    pass

                # Simula a pressão da tecla
                pressed_keys[arrow.key] = True
                current_boy_image = boy_images[arrow.key]
                boy_animation_end = time.time() + 0.5  # Keep animation for 0.5 seconds
                score += 13  # Assume perfect hit
                health = min(config["health_max"], health + config["health_gain"])
                arrows.remove(arrow)  # Remove the arrow after hitting
                break  # Exit the loop after handling one arrow

    # Display health, score, errors, and FPS
    font = pygame.font.Font(None, 36)
    health_text = font.render(f"Health: {health}", True, WHITE)
    score_text = font.render(f"Score: {score}", True, WHITE)
    errors_text = font.render(f"Errors: {errors}", True, WHITE)
    fps = clock.get_fps()
    fps_text = font.render(f"FPS: {int(fps)}", True, WHITE)

    screen.blit(health_text, (10, 10))
    screen.blit(score_text, (10, 50))
    screen.blit(errors_text, (10, 90))
    screen.blit(fps_text, (10, 130))

    pygame.display.flip()
    clock.tick(config["fps_limit"])

    if health <= 0:
        running = False

pygame.quit()